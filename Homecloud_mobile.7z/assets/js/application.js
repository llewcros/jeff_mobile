// Create the global variables when the app starts.
$(document).on('pageshow','#loading',function() {
    //$.mobile.pagecontainer('change',$('#login'),{role:'page'});
    if ($.mobile.currentuser.check()) {
        
        $(":mobile-pagecontainer").pagecontainer( "change", $("#meetingslist" ));
    }else{
        $(":mobile-pagecontainer").pagecontainer( "change", $("#login" ));
    }
    
})

$(document).on('click','#btnlogin',function() {
    
        $.ajax({
            url:$.mobile.appParameters.baseAjaxUrl+'user/user.php',
            method:'GET',
            dataType:'JSON',
            data:{
                action : 'validateUser',
                username : $('#username').val(),
                password : $('#password').val()
            },
            success:function(data) {
                if (data.success) {
                    $.mobile.currentuser.set({
                        userid:data.userid,
                        firstname:data.firstname,
                        lastname:data.lastname
                    })
                    $('#error_panel').hide();
                    $('#username').val('');
                    $('#password').val('');
                    
                    $(":mobile-pagecontainer").pagecontainer( "change", $("#meetingslist" ));
                    
                }else{
                    $('#error_panel').show();
                    
                }
            },
            error:function(a,b,c) {
                alert('Oh no an error ');
                alert(username);
            }
        })
})

$(document).on('pageshow','#meetingslist',function() {
    var currentDate = new Date();
    var day = currentDate.getDate();
    var month = currentDate.getMonth()+1;
    var year = currentDate.getFullYear();
    var date = year+'-'+month+'-'+day;
    getSalespersonMeetings(date);
})

$(document).on('click','#btnrefreshmeetinglist',function() {
    var currentDate = new Date();
    var day = currentDate.getDate();
    var month = currentDate.getMonth()+1;
    var year = currentDate.getFullYear();
    var date = year+'-'+month+'-'+day;
    getSalespersonMeetings(date);
})

$(document).on('click','#btnyesterday',function() {
    var currentDate = new Date();
    currentDate.setDate(currentDate.getDate() -1);
    var day = currentDate.getDate();
    var month = currentDate.getMonth()+1;
    var year = currentDate.getFullYear();
    var date = year+'-'+month+'-'+day;
    getSalespersonMeetings(date);
})

$(document).on('click','#btntomorrow',function() {
    var currentDate = new Date();
    currentDate.setDate(currentDate.getDate() +1);
    var day = currentDate.getDate();
    var month = currentDate.getMonth()+1;
    var year = currentDate.getFullYear();
    var date = year+'-'+('0'+month).slice(-2)+'-'+('0'+day).slice(-2)+'>';
    getSalespersonMeetings(date);
})

$(document).on('click','.btnarrived',function() {
    
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(position) {
            var d = new Date();

            addLeadInteraction({
                leadid:$(this).attr('leadid'),
                salesperson:$.mobile.currentuser.userid,
                description:'Arrived at meeting - '+d+' {'+position.coords.latitude+','+position.coords.longitude+'}',
                status:0
            });
        });
    }
    

    
})



$(document).on('click','.btnleft',function() {
    $('#mr_leadid').val($(this).attr('leadid'));    
    $('#mr_outcome_route').val('meeting');
    
    $(":mobile-pagecontainer").pagecontainer( "change", $("#mr_outcome_page" ));
})

$(document).on('pagecreate','#mr_outcome_page',function() {
    $('#div_start_time').hide();
    $('#div_end_time').hide();
    
    var currentDate = new Date();
    var day = currentDate.getDate();
    var month = currentDate.getMonth()+1;
    var year = currentDate.getFullYear();
    var date = year+'-'+('0'+month).slice(-2)+'-'+('0'+day).slice(-2)+'>';
    
    $('#mr_next_date_month').val(('0'+month).slice(-2));
    $('#mr_next_date_day').val(('0'+day).slice(-2));
    
    $('#mr_next_date_month').selectmenu('refresh',true);
    $('#mr_next_date_day').selectmenu('refresh',true);
    
    
    load_mr_page();
})

$(document).on('pageshow','#mr_outcome_page',function() {
    
    $('#div_start_time').hide();
    $('#div_end_time').hide();
    
    if (parseInt($('#mr_status').val()) === 30) {
        $('#div_start_time').show();
        $('#div_end_time').show();
    }
})


$(document).on('click','#mr_save',function() {
    addMeetingOutcomeActivity({
        leadid:$('#mr_leadid').val(),
        createdby:$.mobile.currentuser.firstname+' '+$.mobile.currentuser.lastname,
        nextactvitydate:$('#mr_next_date_year').val()+'-'+$('#mr_next_date_month').val()+'-'+$('#mr_next_date_day').val(),
        activity:$('#mr_activity').val(),
        status:$('#mr_status').val(),
        starttime:$('#mr_start_time').val(),
        endtime:$('#mr_end_time').val()
    });
    
    
});

$(document).on('click','#mr_outcome_page_back',function() {
    if ($("#mr_outcome_route").val() === 'meeting') {
        $(":mobile-pagecontainer").pagecontainer( "change", $("#meetingslist" ));
    }else{
        
        $(":mobile-pagecontainer").pagecontainer( "change", $("#pending_activity_list" ));
    }
    
})

$(document).on('change','#mr_status',function() {
    
    if (parseInt($(this).val()) === 30) {
        $('#div_start_time').show();
        $('#div_end_time').show();
    }
})

$(document).on('click','#btn_new_appointment',function() {
    $(":mobile-pagecontainer").pagecontainer( "change", $("#new_appointment_page" ));
})

$(document).on('click','#na_save',function() {
    addNewMeeting({
        leadid:$('#na_leadid').val(),
        activity:$('#na_activity').val(),
        nextactivitydate:$('#na_date').val(),
        starttime:$('#na_start_time').val(),
        endtime:$('#na_end_time').val()
    })
})

$(document).on('click','#btn_new_lead',function() {
    $(":mobile-pagecontainer").pagecontainer( "change", $("#lead_page" ));
})

$(document).on('click','#lp_save',function() {
    updateLead({
        action:'appInsertNewLead',
            leadid:0,
            firstname:$('#lp_firstname').val(),
            lastname:$('#lp_lastname').val(),
            contactno:$('#lp_contact_no').val(),
            emailaddress:$('#lp_email_address').val(),
            date:$('#lp_date_year').val()+'-'+$('#lp_date_month').val()+'-'+$('#lp_date_day').val(),
            physicaladdress:$('#lp_physical_address').val(),
            comments:$('#lp_comments').val(),
            area:$('#lp_area').val()
    })
})

$(document).on('click','#btn_logout',function() {
    if ($.mobile.currentuser.logout()) {
        $(":mobile-pagecontainer").pagecontainer( "change", $("#login" ));
    }
})

$(document).on('pageshow','#pending_activity_list',function() {
     var currentDate = new Date();
    var day = currentDate.getDate();
    var month = currentDate.getMonth()+1;
    var year = currentDate.getFullYear();
    var date = year+'-'+month+'-'+day;
    getSalespersonActivities(date);
    
})

$(document).on('click','.btn_activity_respond',function() {
    $('#mr_leadid').val($(this).attr('leadid'));
    $(":mobile-pagecontainer").pagecontainer( "change", $("#mr_outcome_page" ));
    $('#mr_outcome_route').val('activity');
})

$(document).on('pagecreate','#lead_page',function() {
    var currentDate = new Date();
    var day = currentDate.getDate();
    var month = currentDate.getMonth()+1;
    var year = currentDate.getFullYear();
    var date = year+'-'+('0'+month).slice(-2)+'-'+('0'+day).slice(-2)+'>';
    
    $('#lp_date_month').val(('0'+month).slice(-2));
    $('#lp_date_day').val(('0'+day).slice(-2));
    
    $('#lp_date_month').selectmenu('refresh',true);
    $('#lp_date_day').selectmenu('refresh',true);
    
    lead_page_load_areas();
})

//Function to check if the user has logged in before.



