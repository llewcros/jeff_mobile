$(document).on('mobileinit',function() {
    $.mobile.allowCrossDomainPages = true;
    $.mobile.currentuser = currentuser;
    $.mobile.appParameters = appParameters;
    
    $('body[data-role="panel"]').panel();
    
    $.mobile.loader.prototype.options.theme = 'a';
    
})

$(document).ajaxStart(function() {
    $.mobile.loading('show');
})

$(document).ajaxStop(function() {
    $.mobile.loading('hide');
})






