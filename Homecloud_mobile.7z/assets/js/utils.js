var currentuser = {
    userid:0,
    firstname:'',
    lastname:'',
    set:function(userData) {
        this.userid = userData.userid;
        this.firstname = userData.firstname;
        this.password = userData.lastname;
        
        if (localStorage !== undefined) {
            localStorage.setItem('user',userData.userid);
            localStorage.setItem('firstname',userData.firstname);
            localStorage.setItem('lastname',userData.lastname);
        }
    },
    check:function() {
        if (localStorage !== undefined) {
            if (localStorage.getItem('user') !== null) {
                this.userid = localStorage.getItem('user');
                this.firstname = localStorage.getItem('firstname');
                this.lastname = localStorage.getItem('lastname');
                $('#span_currentuser').text(this.firstname);
                return true;
            }else{
                return false;
            }
        }else{
            return false;
        }
    },
    logout:function() {
        if (localStorage !== undefined) {
            if (localStorage.getItem('user')) {
                localStorage.removeItem('user');
                localStorage.removeItem('firstname');
                localStorage.removeItem('lastname');
                return true;
            }
        }
    }
}

var appParameters = {
    baseAjaxUrl : 'http://hcdev.ubambosolutions.co.za/restful/'
}


