function getSalespersonMeetings(date) {
    
    
    $.ajax({
        url:$.mobile.appParameters.baseAjaxUrl+'lead/lead.php',
        type:'GET',
        dataType:'JSON',
        data:{
            action:'getSalespersonMeetings',
            salesperson:$.mobile.currentuser.userid,
            date:date
        },
        success:function(data) {
            $('#meetings').empty().html(data.meetings);
        },
        error:function() {
            alert('There was error');
        }
    })
    
}

function addLeadInteraction(params) {
    //params - leadid, salesperson, description, status
    //alert(params.description);
    $.ajax({
        url:$.mobile.appParameters.baseAjaxUrl+'lead/lead.php',
        type:'POST',
        dataType:'JSON',
        data:{
            action:'updateLeadInteraction',
            lileadid:params.leadid,
            lisalespersonid:params.salesperson,
            liactivity:params.description,
            listatus:params.status
        },
        success:function(data) {
        },
        error:function() {
            alert('There was error');
        }
    })
}

function addMeetingOutcomeActivity(params) {
    $.ajax({
        url:$.mobile.appParameters.baseAjaxUrl+'lead/lead.php',
        type:'POST',
        dataType:'JSON',
        data:{
            action:'saveMeetingOutcomeActivity',
            leadid:params.leadid,
            createdby:params.createdby,
            activity:params.activity,
            nextactivitydate:params.nextactvitydate,
            status:params.status,
            starttime:params.starttime,
            endtime:params.endtime
        },
        success:function(data) {
            //$(":mobile-pagecontainer").pagecontainer( "change", $("#meetingslist" ));
            $('#mr_leadid').val('');
            var currentDate = new Date();
            var day = currentDate.getDate();
            var month = currentDate.getMonth()+1;
            var year = currentDate.getFullYear();

            $('#mr_next_date_year').val(year);
            $('#mr_next_date_month').val(('0'+month).slice(-2));
            $('#mr_next_date_day').val(('0'+day).slice(-2));

            $('#mr_next_date_year').selectmenu('refresh',true);
            $('#mr_next_date_month').selectmenu('refresh',true);
            $('#mr_next_date_day').selectmenu('refresh',true);

            $('#mr_activity').val('');
            $('#mr_status').val('');
            $('#mr_status').selectmenu('refresh',true);

            $('#mr_start_time').val('');
            $('#mr_end_time').val('');
            $('#mr_start_time').selectmenu('refresh',true);
            $('#mr_end_time').selectmenu('refresh',true);

             if ($("#mr_outcome_route").val() === 'meeting') {
                $(":mobile-pagecontainer").pagecontainer( "change", $("#meetingslist" ));
            }else{
                $(":mobile-pagecontainer").pagecontainer( "change", $("#pending_activity_list" ));
            }
        },
        error:function() {
            alert('There was error');
        }
    })
}

function load_mr_page() {
    
    $.ajax({
        url:$.mobile.appParameters.baseAjaxUrl+'lead/lead.php',
        type:'GET',
        dataType:'JSON',
        data:{
            action:'getLeadStatusSelectList'
        },
        success:function(data) {
            $('#mr_status').html(data.html).selectmenu('refresh',true);
        },
        error:function() {
            alert('There was error');
        }
    })
}

function addNewMeeting(params) {
     $.ajax({
        url:$.mobile.appParameters.baseAjaxUrl+'lead/lead.php',
        type:'POST',
        dataType:'JSON',
        data:{
            action:'addNewMeeting',
            leadid:params.leadid,
            activity:params.activity,
            createdby:$.mobile.currentuser.firstname+' '+$.mobile.currentuser.lastname,
            nextactivitydate:params.nextactivitydate,
            starttime:params.starttime,
            endtime:params.endtime
        },
        success:function(data) {
            
        },
        error:function() {
            alert('There was error');
        }
    })
}

function updateLead(params) {
    $.ajax({
        url:$.mobile.appParameters.baseAjaxUrl+'lead/lead.php',
        type:'POST',
        dataType:'JSON',
        data:{
            action:'appInsertNewLead',
            leadid:params.leadid,
            salesperson:$.mobile.currentuser.userid,
            createdby:$.mobile.currentuser.firstname+' '+$.mobile.currentuser.lastname,
            firstname:params.firstname,
            lastname:params.lastname,
            contactno:params.contactno,
            emailaddress:params.emailaddress,
            date:params.date,
            modifiedby:$.mobile.currentuser.firstname+' '+$.mobile.currentuser.lastname,
            physicaladdress:params.physicaladdress,
            comments:params.comments,
            area:params.area
        },
        success:function(data) {
            if (data.success) {
                $('#lrp_span_leadid').text(data.leadid);
                $(":mobile-pagecontainer").pagecontainer( "change", $("#lead_result_page" ));
            }
        },
        error:function() {
            alert('There was error');
        }
    })
}

function getSalespersonActivities(date) {
    $.ajax({
        url:$.mobile.appParameters.baseAjaxUrl+'lead/lead.php',
        type:'GET',
        dataType:'JSON',
        data:{
            action:'getPendingActivities',
            salesperson:$.mobile.currentuser.userid,
            date:date
        },
        success:function(data) {
            $('#pending_activities').empty().html(data.html.activities);
        },
        error:function() {
            alert('There was error');
        }
    })
    
}

function lead_page_load_areas() {
    $.ajax({
        url:$.mobile.appParameters.baseAjaxUrl+'lead/lead.php',
        type:'GET',
        dataType:'JSON',
        data:{
            action:'populateNewLeadOptions'
        },
        success:function(data) {
            
            $('#lp_area').empty().html(data.area).selectmenu('refresh',true);
        },
        error:function() {
            alert('There was error');
        }
    })
}


